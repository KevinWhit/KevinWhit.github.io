/*Kevin Whitlock
1037037
kwhitloc@uoguelph.ca*/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include <ctype.h>

int hash1(char *, int );
int hash2(char *, int );
int hash3(char *, int );
int charTwoint(unsigned char);
