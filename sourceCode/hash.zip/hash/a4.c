/*Kevin Whitlock*/
#include "a4.h"

int charTwoint(unsigned char c){
    /*converts a char into the ascii representation*/
    /*same from lecture except for adding the a case*/

    /*special cases for a and A*/
    if (c=='A'){
        return 65;
    }
    if ( c=='a'){
        return 97;
    }

    /*calculates for the other letters*/
    if(isupper(c)){
        return (int)(c - 'A');
    }

    if(islower(c)){
        return (int)(c - 'a');
    }
    
    return 26;
}



int hash1(char *word, int max){
    /*optimized for the last name*/

    /*holds calculated val*/
    unsigned val;
    char *temp = word;

    /*goes through the word and multiplies the character and increases*/
    for (val = 0; *temp != '\0'; temp++){
        val = *temp + 27*val;
        
    }
        
    /*multiplies by a prime and mods by max size*/    
    return ((val*61) % max); 
}

int hash2(char *word, int max){
    /*optimized for liscense number*/

    /*vars for the prime and value*/
    int prime=17;
    unsigned long val = 0;
    char *temp = word;
    int i;

    /*goes through the word to get each letter*/
    for(i=0; i<strlen(temp); i++){
   
        if (isalpha(temp[i]) || temp[i] == '-'){
            /*for the character*/
            val = prime * val + charTwoint(temp[i]);

        }else if(temp[i] == '-'){
            /*for the -*/
            val = prime * val + 45;

        }else{
            /*for the numbers*/    
            val = prime * val + (temp[i]-'0');
        }      
    }
    val=(val*61)>>2;
   

    /*multiplies by a prime and mods by max size*/
    return (val) % max;
    
}

int hash3(char *word, int max){
    /*optimized for the issue date*/

    /*var for holding the value*/
    unsigned val;
    char *temp = word;

    /*goes through the word and multiplies the character and increases*/
    for (val = 0; *temp != '\0'; temp++){
        val = *temp + 17*val;
    }

      
    /*multiplies by a prime and mods by max size*/
    return ((val*61) % max);
    

}
