#include "a4.h"

#define BUFFER_SIZE 1024

int duplicates;
int collisions;

struct record
{
    char *last_name;
    char *first_name;
    char *combined;
    char *license_no;
    char *license_type;
    char *issue_date;
};

struct array
{
    struct record *arr;
    int nelements;
    struct record **hash;
    int hash_size;
};

int char2int(unsigned char c)
{
    if (isupper(c))
    {
        return (int)(c - 'A');
    }

    if (islower(c))
    {
        return (int)(c - 'a');
    }

    return 26;
}

int str2int(char *arg1, int arg2)
{
    char *c;
    char *s = arg1;
    int max = arg2;
    unsigned long number = 0, column = 1, new = 0;
    for (c = s; (*c); c++)
    {
        number += char2int(*c) * column;
        column *= 73;
    }

    while (number)
    {
        new = (number + (new % max)) % max;
        number /= max;
    }

    return (int)new;
}

struct array *read_records()
{
    struct array *arrptr;
    char buffer[BUFFER_SIZE];
    int x, n;
    int count = 0;

    FILE *fp;

    int line, start, end;

    arrptr = malloc(sizeof(struct array));
    arrptr->nelements = 0;

    fp = fopen("Professional_and_Occupational_Licensing.csv", "r");

    fgets(buffer, BUFFER_SIZE, fp);
    while (!feof(fp))
    {
        if (fgets(buffer, BUFFER_SIZE, fp) == NULL)
        {
            break;
        }

        if (strlen(buffer) == BUFFER_SIZE - 1)
        {
            fprintf(stderr, "Error: BUFFER TOO SMALL\n");
            exit(-1);
        }

        (arrptr->nelements)++;
    }

    arrptr->arr = malloc(sizeof(struct record) * (arrptr->nelements));

    fseek(fp, 0, SEEK_SET);
    fgets(buffer, BUFFER_SIZE, fp);

    for (line = 0; line < arrptr->nelements; line++)
    {
        fgets(buffer, BUFFER_SIZE, fp);

        start = 0;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 1 - last name*/

        (arrptr->arr)[line].last_name = malloc(end - start + 1);
        strncpy((arrptr->arr)[line].last_name, buffer + start, end - start);
        (arrptr->arr)[line].last_name[end - start] = '\0';

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 2 - first name*/

        (arrptr->arr)[line].first_name = malloc(end - start + 1);
        strncpy((arrptr->arr)[line].first_name, buffer + start, end - start);
        (arrptr->arr)[line].first_name[end - start] = '\0';

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 3*/
        (arrptr->arr)[line].combined = malloc(end - start + 1);
        strncpy((arrptr->arr)[line].combined, buffer + start, end - start);
        (arrptr->arr)[line].combined[end - start] = '\0';

        for (n = 0; n < strlen((arrptr->arr)[line].combined); n++)
        {
            if ((arrptr->arr)[line].combined[n] == ',')
            {
                count++;
            }
        }
        for (x = 0; x < count; x++)
        {
            start = end + 1;
            for (end = start; buffer[end] != ','; end++)
                ;
        }

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 4 - license_no*/
        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ;

        (arrptr->arr)[line].license_no = malloc(end - start + 1);
        strncpy((arrptr->arr)[line].license_no, buffer + start, end - start);
        (arrptr->arr)[line].license_no[end - start] = '\0';

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 5*/

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 6 - license_type*/

        (arrptr->arr)[line].license_type = malloc(end - start + 1);
        strncpy((arrptr->arr)[line].license_type, buffer + start, end - start);
        (arrptr->arr)[line].license_type[end - start] = '\0';

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 7*/

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 8*/

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 9*/

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 10*/

        start = end + 1;
        for (end = start; buffer[end] != ','; end++)
            ; /* find next comma col 11 - issue_date*/

        (arrptr->arr)[line].issue_date = malloc(end - start + 1);
        strncpy((arrptr->arr)[line].issue_date, buffer + start, end - start);
        (arrptr->arr)[line].issue_date[end - start] = '\0';
    }
    fclose(fp);
    return arrptr;
}

void build_hash_last_name(struct array *arrptr, int hash_size, int (*hash_function)(char *, int))
{
    int idx, line, duplicate;
    arrptr->hash_size = hash_size;
    arrptr->hash = malloc(sizeof(struct record *) * arrptr->hash_size);

    for (idx = 0; idx < arrptr->hash_size; idx++)
    {
        (arrptr->hash)[idx] = NULL;
    }

    for (line = 0; line < arrptr->nelements; line++)
    {
        /*printf("%d Adding %s\n", line, (arrptr->arr)[line].last_name);*/
        idx = hash_function((arrptr->arr)[line].last_name, (arrptr->hash_size));

        duplicate = 0;

        while ((arrptr->hash)[idx] != NULL)
        {
            if (strcmp(((arrptr->hash)[idx])->last_name, ((arrptr->arr)[line]).last_name) == 0)
            {
                /*printf("Skipping duplicate\n");*/
                duplicate = 1;
                duplicates++;
                break;
            }
            /*printf("Collision at %d %s\n", idx, ((arrptr->hash)[idx])->last_name);*/
            collisions++;
            idx++;
            idx %= arrptr->hash_size;
        }

        if (!duplicate)
        {
            /*printf("Inserting at %d\n", idx);*/
            (arrptr->hash)[idx] = (arrptr->arr) + line;
        }
    }
}

void build_hash_license_no(struct array *arrptr, int hash_size, int (*hash_function)(char *, int))
{
    int idx, line, duplicate;
    arrptr->hash_size = hash_size;
    arrptr->hash = malloc(sizeof(struct record *) * arrptr->hash_size);

    for (idx = 0; idx < arrptr->hash_size; idx++)
    {
        (arrptr->hash)[idx] = NULL;
    }

    for (line = 0; line < arrptr->nelements; line++)
    {
        /*printf("%d Adding %s\n", line, (arrptr->arr)[line].last_name);*/
        idx = hash_function((arrptr->arr)[line].license_no, (arrptr->hash_size));

        duplicate = 0;

        while ((arrptr->hash)[idx] != NULL)
        {
            if (strcmp(((arrptr->hash)[idx])->license_no, ((arrptr->arr)[line]).license_no) == 0)
            {
                /*printf("Skipping duplicate\n");*/
                duplicate = 1;
                duplicates++;
                break;
            }
            /*printf("Collision at %d %s\n", idx, ((arrptr->hash)[idx])->last_name);*/
            collisions++;
            idx++;
            idx %= arrptr->hash_size;
        }

        if (!duplicate)
        {
            /*printf("Inserting at %d\n", idx);*/
            (arrptr->hash)[idx] = (arrptr->arr) + line;
        }
    }
}

void build_hash_issue_date(struct array *arrptr, int hash_size, int (*hash_function)(char *, int))
{
    int idx, line, duplicate;
    arrptr->hash_size = hash_size;
    arrptr->hash = malloc(sizeof(struct record *) * arrptr->hash_size);

    for (idx = 0; idx < arrptr->hash_size; idx++)
    {
        (arrptr->hash)[idx] = NULL;
    }

    for (line = 0; line < arrptr->nelements; line++)
    {
        /*printf("%d Adding %s\n", line, (arrptr->arr)[line].last_name);*/
        idx = hash_function((arrptr->arr)[line].issue_date, (arrptr->hash_size));

        duplicate = 0;

        while ((arrptr->hash)[idx] != NULL)
        {
            if (strcmp(((arrptr->hash)[idx])->issue_date, ((arrptr->arr)[line]).issue_date) == 0)
            {
                /*printf("Skipping duplicate\n");*/
                duplicate = 1;
                duplicates++;
                break;
            }
            /*printf("Collision at %d %s\n", idx, ((arrptr->hash)[idx])->last_name);*/
            collisions++;
            idx++;
            idx %= arrptr->hash_size;
        }

        if (!duplicate)
        {
            /*printf("Inserting at %d\n", idx);*/
            (arrptr->hash)[idx] = (arrptr->arr) + line;
        }
    }
}

void free_array_ptr(struct array *ptr)
{
    int i;

    for (i = 0; i < ptr->nelements; i++)
    {
        free(ptr->arr[i].last_name);
        free(ptr->arr[i].first_name);
        free(ptr->arr[i].license_no);
        free(ptr->arr[i].license_type);
        free(ptr->arr[i].issue_date);
    }

    free(ptr->arr);
    if (ptr->hash)
    {
        free(ptr->hash);
    }

    free(ptr);
}

struct record *find(char *key, struct array *arrptr, int (*hash_function)(char *, int))
{
    int idx;

    idx = hash_function(key, (arrptr->hash_size));

    while ((arrptr->hash[idx]) != NULL)
    {
        if (strcmp(key, ((arrptr->hash)[idx])->last_name) == 0)
        {
            return (arrptr->hash)[idx];
        }
        idx++;

        if (idx >= arrptr->hash_size)
        {
            idx = 0;
        }
    }
    return NULL;
}

int main()
{
    struct array *arrptr;
    int line, max_hash;
    max_hash = 100;

    arrptr = read_records();

    /*build_hash(arrptr, 500000, &str2int);*/
    /*for (line=0;line<arrptr->nelements;line++)
    {
    printf( "%d %s : %s : %s \n", line,
        (arrptr->arr)[line].last_name,
        (arrptr->arr)[line].license_no,
        (arrptr->arr)[line].issue_date);
       
    }*/

    printf("----last_name----\n");
    printf("\nstr2int (base case performance)\n");
    build_hash_last_name(arrptr, 500000, &str2int);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("\nHash Function 1 (optimized for particular key)\n");
    build_hash_last_name(arrptr, 500000, &hash1);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("\nHash Function 2\n");
    build_hash_last_name(arrptr, 500000, &hash2);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("\nHash Function 3\n");
    build_hash_last_name(arrptr, 500000, &hash3);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("----license_no----\n");
    printf("\nstr2int (base case performance)\n");
    build_hash_license_no(arrptr, 500000, &hash1);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("\nHash Function 1\n");
    build_hash_license_no(arrptr, 500000, &hash3);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("\nHash Function 2 (optimized for particular key)\n");
    build_hash_license_no(arrptr, 500000, &hash2);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("\nHash Function 3\n");
    build_hash_license_no(arrptr, 500000, &hash3);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("----issue_date----\n");
    /*printf("\nstr2int (base case performance)\n");
    build_hash_issue_date(arrptr, 500000, &str2int);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;*/

    printf("\nHash Function 1\n");
    build_hash_issue_date(arrptr, 500000, &hash1);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("\nHash Function 2\n");
    build_hash_issue_date(arrptr, 500000, &hash2);
    free(arrptr->hash);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    printf("\nHash Function 3 (optimized for particular key)\n");
    build_hash_issue_date(arrptr, 500000, &hash3);
    printf("\tCollisions: %d\n", collisions);

    collisions = 0;
    duplicates = 0;

    /*free_array_ptr(arrptr);*/

    return 0;
}