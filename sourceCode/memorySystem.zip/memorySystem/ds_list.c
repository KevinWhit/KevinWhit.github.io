/*Kevin Whitlock*/



#include "ds_list.h"
#include "ds_memory.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


void ds_create_list(){

    /*vars*/
    long temp;
    long writtenLong;
    writtenLong=-1;
    
    /*intilizes the list*/
    ds_init("list.bin");

    temp=ds_malloc(sizeof(long));

    ds_write(temp,&writtenLong,sizeof(long));

    ds_finish();
}

int ds_init_list(){

    ds_init("list.bin");

    return 0;
}

int ds_replace(int value, long index){

    /*var display*/
    long int prevLoc=0;
    int i;

    struct ds_list_item_struct previous;
    struct ds_list_item_struct structToChange;

    /*llops through the list*/
    ds_read(&previous.next,0,sizeof(long));
    
    for(i=index;i>0;i--){

        if(previous.next==-1){
            return -1;

        }else{

            prevLoc=previous.next;
            ds_read(&previous,prevLoc, sizeof(previous));
        }
    }

    /*replaces the value*/
    ds_read(&structToChange, previous.next,sizeof(structToChange));
    structToChange.item=value;

    ds_write(previous.next, &structToChange, sizeof(structToChange));


    return 0;
}

int ds_insert(int value, long index){
    
    /*vars*/
    long int prevLoc=0;
    int i;

    struct ds_list_item_struct previous;
    struct ds_list_item_struct new;

    ds_read(&previous.next,0,sizeof(long));
    
    /*loops through the list*/
    for(i=index;i>0;i--){

        if(previous.next==-1){
            return -1;

        }else{

            prevLoc=previous.next;
            ds_read(&previous,prevLoc, sizeof(new));
        }
    }

    /*switches the values*/
    new.next=previous.next;
    new.item=value;
    
    /*mallocs for a new struct*/
    previous.next=ds_malloc(sizeof(previous));
    ds_write(previous.next, &new, sizeof(new));

    if (prevLoc!=0){

        ds_write(prevLoc, &previous, sizeof(new));
        
    }else if (prevLoc==0){

        ds_write(0,&previous.next, sizeof(long));
    }

    return 0;

}



int ds_delete(long index){

    /*delcares variables*/
    int i;
    long prevLoc;

    struct ds_list_item_struct new;
    struct ds_list_item_struct previous;

    ds_read(&previous.next,0,sizeof(long));
    
    /*goes through the list*/
    for(i=index;i>0;i--){

        if(previous.next==-1){
            return -1;

        }else{

            prevLoc=previous.next;
            ds_read(&previous,prevLoc, sizeof(new));
        }
    }

    /*reconnects the list*/
    ds_read(&new, previous.next, sizeof(new));
    previous.next=new.next;

    ds_free(previous.next);
    ds_write(prevLoc, &previous, sizeof(previous));
    
    
    return 0;
}

int ds_swap(long index1, long index2){

    
    int i;


    /*temp structs*/
    struct ds_list_item_struct temp1;
    struct ds_list_item_struct temp2;
    long prevLoc1;
    long prevLoc2;
    long tempItem;


    ds_read(&temp1.next,0,sizeof(long));
    
    /*goes through list for the first struct*/
    for(i=index1;i>0;i--){

        if(temp1.next==-1){
            return -1;

        }else{

            prevLoc1=temp1.next;
            ds_read(&temp1,prevLoc1, sizeof(temp1));
        }
    }

    ds_read(&temp2.next,0,sizeof(long));
    /*goes through list for the second struct*/
    for(i=index2;i>0;i--){

        if(temp2.next==-1){
            return -1;

        }else{

            prevLoc2=temp2.next;
            ds_read(&temp2,prevLoc2, sizeof(temp2));
        }
    }

    /*swaps the items and rewrites*/
    tempItem=temp2.item;

    temp2.item=temp1.item;
    temp1.item=tempItem;

    ds_write(prevLoc1,&temp1,sizeof(temp1));
    ds_write(prevLoc2,&temp2,sizeof(temp2));



    return 0;
}

long ds_find(int target){

    /*delcares vars*/
    long int prevLoc=0;
    int index;

    struct ds_list_item_struct previous;
    struct ds_list_item_struct new;

    ds_read(&previous.next,0,sizeof(long));
    
    /*goes through list and exits when item is found*/
    while (previous.next!=-1){
        
        if(previous.next==-1){
            return -1;

        }else{

            prevLoc=previous.next;
            ds_read(&previous,prevLoc, sizeof(new));
            index++;

            if(previous.item==target){
                return index-1;
            }
        }
    }

    return 0;
    
}

int ds_read_elements(char *filename){

    /*vars*/
    int stored;
    FILE *fp;
    fp=fopen(filename,"rb");
    int count=0;

    /*takes in numbers from a text file*/
    while(!feof(fp)){
        
        fscanf(fp,"%d",&stored);
        ds_insert(stored,count);
        count++;
    }

    
    return 0;
}

int ds_finish_list(){

    ds_finish();

    return 0;
}