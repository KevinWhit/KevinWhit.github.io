/*Kevin Whitlock*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ds_array.h"
#include "ds_memory.h"

int ds_create_array(){

    /*sets global variable*/
    elements=0;

    /*intializes array and writes the global variable*/
    ds_init("array.bin");
    ds_malloc(sizeof(long)+MAX_ELEMENTS);
    ds_write(0,&elements,1);

    /*closes off file anf prints reads and writes*/
    ds_finish();
   
    
    return 0;
}

int ds_init_array(){

    /*intializes array and reads in the elements*/
    ds_init("array.bin");
    fread(&elements, sizeof(long),1 , ds_file.fp);
    
    return 0;
}

int ds_replace(int value, long index){

    /*replaces value at given index*/
    ds_write(index*sizeof(int)+sizeof(elements),&value,sizeof(int));

    return 0;
}

int ds_insert(int value, long index){
    elements++;
    /*vars for insertion*/
    int temp1;
    int temp2;
    int i;

    /*first value*/
    ds_read(&temp1, index*sizeof(int)+sizeof(long), sizeof(temp1));
    
    ds_write(index*sizeof(int)+sizeof(long), &value, sizeof(temp1));

    /*subsiquent values*/
    for (i=index+1; i<elements;i++){

        temp2=temp1;
        ds_read(&temp1, i*sizeof(int)+sizeof(long), sizeof(temp1));
        
        ds_write(i*sizeof(int)+sizeof(long), &temp2, sizeof(temp2));
    }
        
    return 0;
}

int ds_delete(long index){
    
    /*cars for deletion*/
    int temp;
    int i;

    /*reads in next and replace previous*/
    for (i=index+1;i<elements; i++){
        ds_read(&temp, i*sizeof(int)+sizeof(long),sizeof(temp));
        ds_write((i-1)*sizeof(int)+sizeof(long),&temp,sizeof(temp));
    }
    elements--;
        
    return 0;
}

int ds_swap( long index1, long index2){
    /*sawpas values*/
    int valIndex1;
    int valIndex2;

    /*reads in the vals*/
    ds_read(&valIndex1,index1*sizeof(int)+sizeof(long),sizeof(valIndex1));
    ds_read(&valIndex2,index2*sizeof(int)+sizeof(long), sizeof(valIndex2));

    /*writes vals*/
    ds_write(index1*sizeof(int)+sizeof(long),&valIndex2,sizeof(valIndex2));
    ds_write(index2*sizeof(int)+sizeof(long),&valIndex1,sizeof(valIndex1));

    return 0;
}

long ds_find(int target){
/*not full tested*/
    int i;
    int checkValue;

    /*checks all values for the targets*/
    for (i=0;i<elements; i++){
        ds_read(&checkValue,i*sizeof(int)+sizeof(long),sizeof(checkValue));

        if (checkValue==target){
            return i;
        }
    }

    return -1;

    return 0;
}

int ds_read_elements(char *filename){
    /*not full tested*/
    int stored;
    FILE *fp;
    fp=fopen(filename,"rb");
    int count=0;

    /*takes in numbers from a text file*/
    while(!feof(fp)){
        
        fscanf(fp,"%d",&stored);
        ds_insert(stored,count);
        count++;
    }

    return 0;
}

int ds_finish_array(){
    
    /*closes out arrays*/
    ds_finish();
    return 0;
}