/*Kevin Whitlock*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ds_memory.h"



int ds_create(char *filename, long size){

    /*variable declarations*/
    
    int i;
    int testCount=0;
    FILE *fp;
    /*opens file*/
    fp=fopen(filename,"wb");

    /*first element*/
    ds_file.block[0].start=0;
    ds_file.block[0].length=size;
    ds_file.block[0].alloced=0;

    /*every other element*/
    for (i=1; i<MAX_BLOCKS-1; i++){

        ds_file.block[i].start=0;
        ds_file.block[i].length=0;
        ds_file.block[i].alloced=0;
 
    }
    /*writes the header*/
    fwrite(&ds_file.block, sizeof(ds_file.block),1,fp);

    char temp=0;
    
    /*writes the additonal bytes*/
    for (i=0;i<size;i++){
        fwrite(&temp,sizeof(char),1,fp);
    }

    fclose(fp);

    return 0;
    
}

int ds_init(char *filename){
    int i;
    /*opens file*/
    ds_file.fp =fopen(filename,"r+");

    /*read in header*/ 
    
    fread(&ds_file.block,sizeof(ds_file.block),1,ds_file.fp);
    /*sets reads writes*/
    
    ds_counts.reads=0;
    ds_counts.writes=0;

        

    return 0;
}

long ds_malloc(long amount){
    /*allocs space as an index in the bin file*/
    int i;
    int j;
    int tempLength;
    int tempIndex=0;


    for(i=0;i<MAX_BLOCKS; i++){
        if(ds_file.block[i].length >= amount && ds_file.block[i].alloced==0){
            /*finds the next available unalloced space*/
            tempLength=ds_file.block[i].length;
            ds_file.block[i].length=amount;
            ds_file.block[i].alloced =1;
            tempIndex = i;

            for(j=0;j<MAX_BLOCKS;j++){
                /*claims the space*/
                if (ds_file.block[j].length == 0){
                    ds_file.block[j].start=ds_file.block[tempIndex].start + amount;
                    ds_file.block[j].length = tempLength - amount;
                    ds_file.block[j].alloced=0;
                    
                    return ds_file.block[tempIndex].start;

                }
            }
        }
    
    }
    return -1;

    }
   
void ds_free(long start){
    int i;
    /*free memoty*/
    for (i=0;i<MAX_BLOCKS;i++){
        if (ds_file.block[i].start==start){ 
            ds_file.block[i].alloced=0;
            
        }
    }

}

void *ds_read (void *ptr, long start, long bytes){
    /*reads the data*/
    
    fseek(ds_file.fp,sizeof(ds_file.block)+start,SEEK_SET);

    fread(ptr,bytes,1,ds_file.fp);

    ds_counts.reads++;


    return ptr;
}

long ds_write(long start, void *ptr, long bytes){
    /*writes the data*/
    
    fseek(ds_file.fp, sizeof(ds_file.block)+start, SEEK_SET);

    fwrite(ptr, bytes, 1, ds_file.fp);

    ds_counts.writes++;

    return start;
}

int ds_finish(){
    /*house keeping*/
    FILE *writeFp =fopen("writes.txt","a");
    FILE *readFp =fopen("reads.txt","a");

    fseek(ds_file.fp,0,SEEK_SET);
    fwrite(&ds_file.block,sizeof(ds_file.block),1,ds_file.fp);
    
    fclose(ds_file.fp);

    printf("Reads: %d\n", ds_counts.reads);
    printf("Writes: %d\n", ds_counts.writes);

    fprintf(writeFp,"%d\n", ds_counts.writes);
    fprintf(readFp,"%d\n", ds_counts.reads);

    fclose(writeFp);
    fclose(readFp);

    return 0;
}


