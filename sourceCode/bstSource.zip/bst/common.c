#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "common.h"


char* get_column(char* input, int col){
    int tabCount=0;
    char* output;
    char temp[256];
    int i=0;
    int j=0;
    int length ;
    int savedOne=0;
    int savedTwo=0;
    int count=0;

    /*goes through the line*/
    for(i=0;i<strlen(input);i++){
        if(input[i]=='\t' || input[i]=='\n'){
            tabCount++;

            /*/saves first index*/
            if(tabCount == col ){
                savedOne = i;
            }

            /*saves second index*/
            if(tabCount==col+1){
                savedTwo = i;
                break;
            }
        }
    }

    /*increments first index to remove tab*/
    if(col!=0){
        savedOne=savedOne+1;
    }
    
    
    /*mallocs and saves over string*/
    output = malloc(sizeof(char) * (savedTwo-savedOne+1));
    strncpy(output,&input[savedOne],(savedTwo-savedOne));
    /*printf("[%s]\n", output);*/

    return output;
}

char* reverse(char* input){
    /*reverses to not blow the stack*/
    int start;
    int end;
    char temp;
    int isMod=0;
    start=0;


    end=(strlen(input)-1);
    if(strlen(input)%2==0){
        isMod=1;
    }

    while(start!=end){
        
        temp=input[start];
        input[start]=input[end];
        input[end]=temp;
        
        if((start+1)==end&&(isMod==1)){
            break;
        }

        start++;
        end--;
    }

    return input;

}
 