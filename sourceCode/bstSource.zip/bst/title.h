#include<stdio.h>
#include<string.h>
#include<stdlib.h>


struct title_data* get_title(char*);
void build_ptindex(struct title_data*);
struct title_basics* find_primary_title(struct title_data*, char *);
void build_tconstIndex(struct title_data* );
struct title_basics* find_tconst(struct title_data*, char * );

struct title_basics{
    char *tconst;
    char *primaryTitle;
};

struct title_data{
    int numElements;
    struct title_basics* arrayAdd;
    struct tree* root1;
    struct tree* root2;
};



