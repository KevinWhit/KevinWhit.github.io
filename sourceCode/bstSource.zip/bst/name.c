1#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "name.h"
#include "common.h"
#include "binary.h"


struct name_data* get_name(char* filePath){

    char * pathOfFile;
    char * recieved=NULL;
    char * tempNconst=NULL;
    char ext[30] = "/name.basics.tsv";
    struct name_basics* nameArrPtr;
    struct name_data* storedData;
    char buffer[1024];
    int count=0;
    int line=0;
    FILE* fp;

    /*Opens the file path*/
    /*pathOfFile=malloc((sizeof(char)*strlen(filePath))+(sizeof(char)*strlen(ext))+1);
    strcpy(pathOfFile,filePath);
    strcat(pathOfFile,ext);*/
    fp=fopen("name.basics.tsv","r");

    /*goes through the file and calculates how many actors there are*/
    while(!feof(fp)){

        if(fgets(buffer, 1024, fp)!=NULL){

            recieved=get_column(buffer, 4);
            
            /*increases if theres an actor or actress*/
            if(strstr(recieved,"actor") || strstr(recieved,"actress") ){
                count++;
            }    
        }    
    }

    /*mallocs for how many elements then goes through them storing data*/
    nameArrPtr=malloc(sizeof(struct name_basics)*count);
    fseek(fp,0, SEEK_SET);

    /*parses the data into the struct*/
    while(!feof(fp)){
        if(fgets(buffer, 1024, fp)!=NULL){

            recieved=get_column(buffer, 4);

            /*increases if theres an actor or actress*/
            if(strstr(recieved,"actor") || strstr(recieved,"actress") ){
                
                /*stores the nconst*/
                tempNconst=(get_column(buffer,0));
                nameArrPtr[line].nconst=(reverse(tempNconst));
                nameArrPtr[line].primaryName=(get_column(buffer,1));
                line++;
            } 
        }
    }

    /*sets up the data struct*/
    storedData = malloc(sizeof(struct name_data));
    storedData->numElements = count;
    storedData->arrayAdd = nameArrPtr;
    storedData->root1 = 0;
    storedData->root2 = 0;

    /*frees file path*/
    /*free(pathOfFile);*/   
    fclose(fp);
    return storedData;
}

void build_nameIndex(struct name_data* arrayRec){
    /*build the name tree*/
    int i;
    for(i=0;i<arrayRec->numElements; i++){
        add_node (&(arrayRec->root1), arrayRec->arrayAdd[i].primaryName, arrayRec->arrayAdd+i);
    }
}

struct name_basics* find_primary_name(struct name_data* arrayRec, char *nameRec){
    /*finds a certain name*/
    struct tree* temp;

    temp=find_node(arrayRec->root1, nameRec );

    if(temp==NULL){
        printf("Didnt find Node\n");
    }
    
    return (temp->data);
}

void build_nconstIndex(struct name_data* arrayRec){
    /*nconst tree for name*/
    int i;
    for(i=0;i<arrayRec->numElements; i++){
        /*printf("%s\n",arrayRec->arrayAdd[i].primaryTitle);*/
        add_node (&(arrayRec->root2), arrayRec->arrayAdd[i].nconst, arrayRec->arrayAdd+i);
    }
}

struct name_basics* find_nconst(struct name_data* arrayRec, char * nameRec){
    /*finds the nconst*/
    struct tree* temp;
    
    temp=find_node(arrayRec->root2, nameRec );

    if(temp==NULL){
        printf("name nconst Null\n");
    }
    

    return (temp->data);
}


