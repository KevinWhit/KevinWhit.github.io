#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "common.h"
#include "title.h"
#include "binary.h"



struct title_data* get_title(char* filePath){
    char * pathOfFile;
    char * recieved=NULL;
    char* tempTconst=NULL;
    char * adult=NULL;
    char * movie=NULL;
    char ext[30] = "/title.basics.tsv";
    struct title_basics *titleArrPtr;
    struct title_data * storedData;
    char buffer[1024];
    int titleCount=0;
    int line=0;
    FILE* fp;

    /*opens the file*/
    /*pathOfFile=malloc((sizeof(char)*strlen(filePath))+(sizeof(char)*strlen(ext))+1);
    strcpy(pathOfFile,filePath);
    strcat(pathOfFile,ext);*/
    fp=fopen("title.basics.tsv","r");

    /*calculates how many lines there are*/
    while(!feof(fp)){

        if(fgets(buffer, 1024, fp)!=NULL){
            /*zero is tconst 3 is names*/
            /*1 is movie type, 4 is adult*/
            movie=get_column(buffer, 1);
            adult=get_column(buffer, 4);
            /*printf("[%s]   [%s]\n", movie, adult);*/

            if(strcmp(movie,"movie")==0 && strcmp(adult,"0")==0){
                titleCount++;    
            }
            
        }
    }
    movie=NULL;
    adult=NULL;

    titleArrPtr=malloc(sizeof(struct title_basics)*titleCount);
    fseek(fp, 0, SEEK_SET);

    /*Fills the struct with the data*/
    while(!feof(fp)){
        if(fgets(buffer, 1024, fp)!=NULL){

            movie=get_column(buffer, 1);
            adult=get_column(buffer, 4);
            /*printf("[%s]   [%s]\n", movie, adult);*/

            if(strcmp(movie,"movie")==0 && strcmp(adult,"0")==0){
                
                /*stores the mebers*/
                tempTconst = get_column(buffer, 0);
                titleArrPtr[line].tconst = reverse(tempTconst);
                titleArrPtr[line].primaryTitle = get_column(buffer, 3);

                /*printf("[%s]   [%s]\n",titleArrPtr[line].tconst,titleArrPtr[line].primaryTitle);*/

                line++;   
            }
        }

    }
    
    /*does the stored Data*/
    storedData = malloc(sizeof(struct title_data));
    storedData->numElements = titleCount;
    storedData->arrayAdd = titleArrPtr;
    storedData->root1 = 0;
    storedData->root2 = 0;


    /*free(pathOfFile);*/
    fclose(fp);

    return storedData;
}

void build_ptindex(struct title_data* arrayRec){
    /*buidls the title tree*/
    int i;
    for(i=0;i<arrayRec->numElements; i++){
        /*printf("%s\n",arrayRec->arrayAdd[i].primaryTitle);*/
        add_node (&(arrayRec->root1), arrayRec->arrayAdd[i].primaryTitle, arrayRec->arrayAdd+i);
    }

}

struct title_basics* find_primary_title(struct title_data* arrayRec, char * nameRec){
    /*finds the title*/
    struct tree* temp;


    temp=find_node(arrayRec->root1, nameRec );
    if(temp==NULL){
        printf("title title Null\n");
    }
    
    return (temp->data);
}

void build_tconstIndex(struct title_data* arrayRec){
    /*finds  t const*/
    int i;
    for(i=0;i<arrayRec->numElements; i++){

        add_node (&(arrayRec->root2), arrayRec->arrayAdd[i].tconst, arrayRec->arrayAdd+i);
    }
}

struct title_basics* find_tconst(struct title_data* arrayRec, char * nameRec){
    
    struct tree* temp;
    
    temp=find_node(arrayRec->root2, nameRec );

    if(temp==NULL){
        printf("title t Null\n");
    }
    

    return (temp->data);
}
