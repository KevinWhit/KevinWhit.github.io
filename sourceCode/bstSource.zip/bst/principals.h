#include<stdio.h>
#include<string.h>
#include<stdlib.h>


struct principals_data* get_principals(char* );

void build_tconst_tp(struct principals_data*);
struct title_principals* find_tconst_tp(struct principals_data*, char*);

void build_nconst_tp(struct principals_data*);
struct title_principals* find_nconst_tp(struct principals_data*, char * );



struct title_principals{
    char* tconst;
    char* nconst;
    char* characters;
};

struct principals_data{
    int numElements;
    struct title_principals* arrayAdd;
    struct tree* root1;
    struct tree* root2;
};