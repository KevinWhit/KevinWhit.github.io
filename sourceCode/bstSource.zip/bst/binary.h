#include<stdio.h>
#include<string.h>
#include<stdlib.h>


struct tree
{
  char* key;
  void* data;
  struct tree *children[2];
};

void add_node(struct tree**, char*, void*  );
struct tree* find_node(struct tree* , char* );
void print_tree( struct tree *, char* );
void free_tree(struct tree*);

/*Need three different ones in the other h files.*/
