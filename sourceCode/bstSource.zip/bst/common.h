#include<stdio.h>
#include<string.h>
#include<stdlib.h>


char* get_column(char*, int );
char* reverse(char*);





