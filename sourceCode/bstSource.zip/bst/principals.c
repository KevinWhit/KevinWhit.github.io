#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "principals.h"
#include "common.h"
#include"binary.h"

struct principals_data* get_principals(char* filePath){

    char * pathOfFile;
    char * recieved=NULL;
    char *tempNconst=NULL;
    char *tempTconst=NULL;
    char ext[30] = "/title.principals.tsv";
    struct title_principals *princArrPtr;
    struct principals_data* storedData;
    char buffer[1024];
    int count=0;
    int line=0;
    FILE* fp;

    /*opens the file*/
    /*pathOfFile=malloc((sizeof(char)*strlen(filePath))+(sizeof(char)*strlen(ext))+1);
    strcpy(pathOfFile,filePath);
    strcat(pathOfFile,ext);*/
    fp=fopen("title.principals.tsv","r");

    /*finds how many line*/
    while(!feof(fp)){

        if(fgets(buffer, 1024, fp)!=NULL){
            /*3 is actor
            0 is nconst
            2 is tconst
            5 is characters*/
            recieved = get_column(buffer, 3);

            if(strcmp(recieved,"actor")==0 || strcmp(recieved,"actress")==0 ){
                count++;
            }
            
        }
    }
    
    
    princArrPtr=malloc(sizeof(struct title_principals)*count);
    fseek(fp,0, SEEK_SET);

    /*puts the info into the structs*/
    while(!feof(fp)){

        if(fgets(buffer, 1024, fp)!=NULL){
            /*3 is actor
            0 is nconst
            2 is tconst
            5 is characters*/
            recieved = get_column(buffer, 3);

            if(strcmp(recieved,"actor")==0 || strcmp(recieved,"actress")==0 ){
                
                tempNconst=(get_column(buffer,2));
                tempTconst=(get_column(buffer,0));
                princArrPtr[line].nconst=reverse(tempNconst);
                princArrPtr[line].tconst=reverse(tempTconst);
                princArrPtr[line].characters=(get_column(buffer,5));
                /*printf("[%s] [%s] [%s]\n", princArrPtr[line].nconst, princArrPtr[line].tconst, princArrPtr[line].characters);*/
                line++;
            }
            
        }
    }

    /*stores the data struct*/
    storedData = malloc(sizeof(struct principals_data));
    storedData->numElements = count;
    storedData->arrayAdd = princArrPtr;
    storedData->root1 = 0;
    storedData->root2 = 0;

    free(pathOfFile);
    fclose(fp);

    return storedData;
}

void build_tconst_tp(struct principals_data* arrayRec){
    /*principal tconst tree*/
    int i;
    for(i=0;i<arrayRec->numElements; i++){
        /*printf("%s\n",arrayRec->arrayAdd[i].primaryTitle);*/
        add_node (&(arrayRec->root1), arrayRec->arrayAdd[i].tconst, arrayRec->arrayAdd+i);
    }
}

struct title_principals* find_tconst_tp(struct principals_data* arrayRec, char* nameRec){
    /*finds the specific tconst*/
    struct tree* temp;
    
    temp=find_node(arrayRec->root1,nameRec );
    if(temp==NULL){
        printf("princ t Null\n");
    }
    

    return (temp->data);
}


void build_nconst_tp(struct principals_data* arrayRec){
    /*builds the nconst tree*/
    int i;
    for(i=0;i<arrayRec->numElements; i++){
        /*printf("%s\n",arrayRec->arrayAdd[i].primaryTitle);*/
        add_node (&(arrayRec->root2), arrayRec->arrayAdd[i].nconst, arrayRec->arrayAdd+i);
    }
}

struct title_principals* find_nconst_tp(struct principals_data* arrayRec, char * nameRec){
    /*finds specific nConst*/
    struct tree* temp;
    
    
    temp=find_node(arrayRec->root2, nameRec );

    if(temp==NULL){
        printf("prince n Null\n");
    }
    
    
    return (temp->data);
}

