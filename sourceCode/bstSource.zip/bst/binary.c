#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "common.h"
#include "binary.h"

#include "title.h"


void add_node(struct tree** root, char* title, void* arrayPtr ){
    /*adds the node for the specific tree*/
    if(*root){
        if(strcmp((*root)->key,title)<0){
            add_node(&((*root)->children[0]), title, arrayPtr);

        }else{
            add_node(&((*root)->children[1]), title, arrayPtr);

        }
    }else{
        (*root)=malloc(sizeof(struct tree));
        (*root)->data = arrayPtr;
        (*root)->key = title;
        (*root)->children[0]=NULL;
        (*root)->children[1]=NULL;
    }

}

struct tree* find_node(struct tree *root, char* value){
    /*finds the node*/
    if (root){
        if(strcmp(root->key,value)==0){
            return root;
        }else{
            if(strcmp((root)->key,value)<0){
                return find_node( root->children[0], value);
            }else{
                return find_node(root->children[1], value);
            }
        }
    }else{
        return NULL;
    }
}

void free_tree( struct tree *root ){
    /*free the tree*/
    if (root){
        free_tree( root->children[0] );
        free_tree( root->children[1] );
        free( root );
    }
}


