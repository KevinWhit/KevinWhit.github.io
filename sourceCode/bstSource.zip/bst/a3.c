#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "title.h"
#include "common.h"
#include "name.h"

#include "principals.h"

#include "binary.h"
#include "a3.h"

int main(int argc, char *argv[]){
    int i;
    int j=0;
    int k=0;
    int savedIn;
    struct title_data* titleRec;
    struct name_data* nameRec;
    struct principals_data* princRec;
    struct title_basics* title;
    struct name_basics* name;
    
    struct tree* principalTree;
    struct tree* tree2;
    struct title_principals* principals;
    struct tree* princeTree;
    
    char* ret;
    char lineBuffer[256];
    char command[256];
    char toSearch[256];
    
  
    /*collects the stuff from the user*/
    printf("Enter the command and item to search\n");
    fgets(lineBuffer, 256, stdin);

    for(j=0; j<strlen(lineBuffer);j++){
        if(lineBuffer[j]==' '){
            savedIn=j;
            break;
        }
        command[j]=lineBuffer[j];
    }

    for(j=savedIn+1; j<strlen(lineBuffer);j++){
        if(lineBuffer[j]==' ' || lineBuffer[j]=='\n'){
            if(lineBuffer[j+1]==' ' || lineBuffer[j+1]=='\n'){
                break;
            }
            toSearch[k]=' ';
            k++;
        }else
        {
            toSearch[k]=lineBuffer[j];
            k++;
        }
           
    }
    command[strlen(command)]='\0';
    toSearch[strlen(toSearch)-1]='\0';
    

    
    titleRec = get_title(argv[1]);
    build_ptindex(titleRec);
    build_tconstIndex(titleRec);

    
    nameRec=get_name(argv[1]);
    build_nameIndex(nameRec);
    build_nconstIndex(nameRec);

    
    princRec=get_principals(argv[1]);
    
    build_tconst_tp(princRec);
    
    build_nconst_tp(princRec);

    
    
    if(strcmp(command,"name")==0){

        name=find_primary_name(nameRec,"Iron Man");
        principals=find_nconst_tp(princRec,name->nconst);
        title = find_tconst(titleRec,principals->tconst);
        
        printf("%s\n",title->primaryTitle);
        printf("%s\n",principals->characters);



        /*
        while (princeTree) {
                principals = princeTree->data;

                if (strcmp(name->nconst, princeTree->children[1]->data) == 0) {
                    title = find_tconst(titleRec, principals->tconst);
                    printf("%s : %s\n", title->primaryTitle, principals->characters);                    
                }

                if (strcmp(name->nconst, princeTree->children[0]->data) < 0) {
                    princeTree = princeTree->children[0];
                } else {
                    princeTree = princeTree->children[1];
                }

            }  */
    
        
    }else if(strcmp(command,"title")==0){

        title = find_primary_title(titleRec,toSearch);
        principals = find_tconst_tp(princRec,(title->tconst));
        name = find_nconst(nameRec,(principals->nconst));

        printf("%s\n",name->primaryName);
        printf("%s\n",principals->characters);
    }

    

    free_tree(nameRec->root1);
    free_tree(nameRec->root2);
    free_tree(princRec->root1);
    free_tree(princRec->root2);
    free_tree(titleRec->root1);
    free_tree(titleRec->root2);
























    /*main Test*/
    /*printf("Before TItle\n");
    titleRec = get_title(argv[1]);
    build_ptindex(titleRec);
    build_tconstIndex(titleRec);

    printf("Before Name\n");
    nameRec=get_name(argv[1]);
    build_nameIndex(nameRec);
    build_nconstIndex(nameRec);

    printf("Before prince\n");
    princRec=get_principals(argv[1]);
    printf("Before tConst\n");
    build_tconst_tp(princRec);
    printf("Before nConst\n");
    build_nconst_tp(princRec);

    printf("READY\n");

    name=find_primary_name(nameRec,"Bruce Lee");
    principals=find_nconst_tp(princRec,name->nconst);
    title = find_tconst(titleRec,principals->tconst);
    printf("%s\n",title->primaryTitle);*/


    
    

    /*title = find_primary_title(titleRec,"Blade Runner");
    printf("%s",title->tconst);*/


    /*
    title = find_primary_title(titleRec,"Blade Runner");
    principals = find_tconst_tp(princRec,(title->tconst));
    name = find_nconst(nameRec,(principals->nconst));

    printf("%s\n",name->primaryName);*/

    /*check princ alone*/
    /*
    printf("Before TItle\n");
    titleRec = get_title(argv[1]);
   /*nameRec=get_name(argv[1]);*/
    
    /*princRec=get_principals(argv[1]);*/

    
    /*build_tconstIndex(titleRec);
    title=find_tconst(titleRec,"4860800t");*/
    /*printf("%s", reverse(test));*/


    /*build_nconstIndex(nameRec);
    
    name=find_nconst(nameRec, "5530000m");
    printf( "[%s]\n", name->nconst );
    printf( "[%s]\n", name->primaryName );*/
    /*print_tree(titleRec->root1,"");*/

    
    /*printf("before find\n");*/
    /*title = find_primary_title(titleRec,"Star Wars: Episode V - The Empire Strikes Back");
    printf("after find\n");
    printf( "[%s]\n", title->tconst );
    printf( "[%s]\n", title->primaryTitle );*/



    /*printf( "%s\n", ((struct title_basics *)((titleRec->numElements)->value))->primaryTitle );

    printf( "%s\n", ((struct title_basics *)((titleRec->numElements)->value))->tconst );
    
    *//*prints out the stuff for testing*/
    /*printf("%d",princRec->numElements);
    for (i=0;i<princRec->numElements; i++){

        printf("%s\n",princRec->arrayAdd[i].characters);
    }*/
    

    return 0;
}