#include<stdio.h>
#include<string.h>
#include<stdlib.h>


struct name_data* get_name(char*);

void build_nameIndex(struct name_data*);
struct name_basics* find_primary_name(struct name_data* , char *);

void build_nconstIndex(struct name_data* );
struct name_basics* find_nconst(struct name_data* , char * );

struct name_basics{
    char *nconst;
    char *primaryName;
};

struct name_data{
    int numElements;
    struct name_basics* arrayAdd;
    struct tree* root1;
    struct tree* root2;
};